let fundoatual = "fundos/fnaf1.jpg";

    function equip(fundoescolhido){
        if (fundoescolhido == "fnaf1"){
            fundoatual = "fundos/fnaf1.jpg";
        }
        else if (fundoescolhido == "ucn") {
            fundoatual = "fundos/ucn_office.jpg";
        }
        else if (fundoescolhido == "fnaf3"){
            fundoatual = "fundos/fnaf3.jpg"
        }
        else if(fundoescolhido == "fnaf2"){
            fundoatual = "fundos/fnaf2.jpg"
        }
        else if(fundoescolhido == "fnaf4"){
            fundoatual = "fundos/fnaf4.jpg"
        }
        else if(fundoescolhido == "fnaf5"){
            fundoatual = "fundos/fnaf5.jpg"
        }
        localStorage.setItem("fundoEscolhido", fundoatual);
    }